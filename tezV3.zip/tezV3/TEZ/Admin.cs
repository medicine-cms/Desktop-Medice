﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TEZ.Data;

namespace TEZ
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
            Load += new EventHandler(Admin_Load);
        }
        private void Admin_Load(object sender, EventArgs e)
        {
            SqlConnection cnn = DBConnect.getConnection();
            cnn.Open();

            if (cnn.State != ConnectionState.Open)
            {
                MessageBox.Show("Fail");
            }
            else
            {
                MessageBox.Show("Success");
                if (!serialPort1.IsOpen)
                {
                    serialPort1.Open();
                    MessageBox.Show("Kart Okuyucuya başarılı bir şekilde Bağlanıldı.");
                }
            }
            cnn.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loginA loga = new loginA();
            this.Hide();
            loga.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            Login log = new Login();
            this.Close();
            log.ShowDialog();
                       
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            string startsWith = "The tag's number is:";
            SerialPort sp = (SerialPort)sender;
            string indata = sp.ReadExisting();
            int tagNumber = 0;
            try
            {
                indata.Split(Environment.NewLine.ToCharArray())      // split on newline chars
                      .FirstOrDefault(s => s.Contains(startsWith)) // get first string matching pattern above 
                      .Split(':')                                    // split on ':'
                      .FirstOrDefault(x => int.TryParse(x, out tagNumber));  // return first successful try parse
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            txtKartid.Text = tagNumber.ToString();
            MessageBox.Show(tagNumber.ToString());

        }       

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            
            // Receive Data
            int hastaid = Int32.Parse(txtHastaId.Text);
            int kartid = Int32.Parse(txtKartid.Text);
            SqlConnection cnn = DBConnect.getConnection();
            cnn.Open();
            //string sqlinsertQuery = "UPDATE HASTA SET Kart_ID = '"+ kartid + "' WHERE Hasta_TC_Kimlik_No = '" + hastaid + "' ";
            SqlCommand cmdUpdate = new SqlCommand("UPDATE HASTA SET Kart_ID = '" + kartid + "' WHERE Hasta_TC_Kimlik_No = '" + hastaid + "' ", cnn);
            cmdUpdate.ExecuteNonQuery();
            cnn.Close();
        }
        private Point mouseOffset;
        private bool isMouseDown = false;

        private void Admin_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void Admin_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void Admin_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }
    }
}
