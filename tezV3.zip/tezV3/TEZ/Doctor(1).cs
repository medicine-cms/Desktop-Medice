﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using TEZ.Data;
using System.IO.Ports;

namespace TEZ
{
    public partial class Doctor : Form
    {
        public Doctor()
        {
            //this.Hide();
            InitializeComponent();
            Load += new EventHandler(Doctor_Load);
            
        }
        private void Doctor_Load(object sender, EventArgs e)
        {
            SqlConnection cnn = DBConnect.getConnection();
            cnn.Open();

            if (cnn.State != ConnectionState.Open)
            {
                MessageBox.Show("Fail");
            }
            else
            {
                MessageBox.Show("Success");
                if (!serialPort1.IsOpen)
                {
                    serialPort1.Open();
                    MessageBox.Show("Kart Okuyucuya başarılı bir şekilde Bağlanıldı.");
                }
            }
            cnn.Close();
        }
        private void serialPort1_DataReceived_1(object sender, SerialDataReceivedEventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            string startsWith = "The tag's number is:";
            SerialPort sp = (SerialPort)sender;
            string indata = sp.ReadExisting();
            int tagNumber = 0;
            try
            {
                indata.Split(Environment.NewLine.ToCharArray())      // split on newline chars
                      .FirstOrDefault(s => s.Contains(startsWith)) // get first string matching pattern above 
                      .Split(':')                                    // split on ':'
                      .FirstOrDefault(x => int.TryParse(x, out tagNumber));  // return first successful try parse
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

            //label2.Text = tagNumber.ToString();
            // Receive Data
            SqlConnection cnn = DBConnect.getConnection();
            cnn.Open();
            string sqlSelectQuery = "SELECT * FROM HASTA WHERE KART_ID= " + int.Parse(tagNumber.ToString());
            SqlCommand cmd = new SqlCommand(sqlSelectQuery, cnn);
            SqlDataReader dr = cmd.ExecuteReader();
            int yas;
            DateTime dogumtarihi;

            if (dr.Read())
            {
                dogumtarihi = Convert.ToDateTime(dr["Hasta_Dogum_Tarihi"]);
                yas = DateTime.Now.Year - dogumtarihi.Year; // Calculate age
                label2.Text += (dr["Hasta_TC_Kimlik_No"].ToString());
                label2.Text += (dr["Hasta_Ad"].ToString());
                label2.Text += (dr["Hasta_Soyad"].ToString());
                label2.Text += yas.ToString();
                label2.Text += (dr["Alerji"].ToString());
                label2.Text += (dr["Kronik_Hastalik"].ToString());
                label2.Text += (dr["Hasta_ID"].ToString());               
                
            }
            cnn.Close();


        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            loginD logd = new loginD();
            logd.ShowDialog();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            this.Hide();
            log.ShowDialog();
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

     
    }
}
