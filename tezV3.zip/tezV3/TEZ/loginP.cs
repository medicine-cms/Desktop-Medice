﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using TEZ.Data;

namespace TEZ
{
    public partial class loginP : Form
    {       
        
        public loginP()
        {
            InitializeComponent();
            textBox2.PasswordChar = '*';
        }

        private void button1_Click(object sender, EventArgs e)
        {         
            string phrmid = textBox1.Text;
            int phrmidint;
            bool res = int.TryParse(phrmid, out phrmidint);
            string phrmpass = textBox2.Text;
            SqlConnection cnn = DBConnect.getConnection();
            SqlCommand cmd;
            SqlDataReader dr;
            cmd = new SqlCommand();
            cnn.Open();
            cmd.Connection = cnn;
            cmd.CommandText = "SELECT * FROM ECZANE WHERE Eczane_ID='" + phrmidint+ "' AND Eczane_Password='" + phrmpass+ "'";
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Pharma phrm = new Pharma();
                MessageBox.Show("Tebrikler! Başarılı bir şekilde giriş yaptınız.");
                phrm.phrmid = textBox1.Text;
                this.Hide();
                phrm.ShowDialog(); 
            }
            else
            {
                label2.Visible = true;
            }
            cnn.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login log = new Login();            
            log.ShowDialog();
            this.Hide();
        }
    }
}
