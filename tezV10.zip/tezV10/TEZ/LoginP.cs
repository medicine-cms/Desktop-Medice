﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using TEZ.Data;

namespace TEZ
{
    public partial class LoginP : Form
    {
        public LoginP()
        {
            InitializeComponent();
            P_pass.PasswordChar = '*';
        }
        SqlConnection cnn = DBConnect.getConnection();

        private void main_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Close();
            login.ShowDialog();
        }

        private void P_gir_Click(object sender, EventArgs e)
        {
            string phrmusername = P_id.Text;
            string phrmpass = P_pass.Text;
            SqlConnection cnn = DBConnect.getConnection();
            SqlCommand cmd;
            SqlDataReader dr;
            cmd = new SqlCommand();
            cnn.Open();
            cmd.Connection = cnn;
            cmd.CommandText = "SELECT * FROM ECZANE WHERE Eczane_Kullanici_Adi='" + phrmusername + "' AND Eczane_Password='" + phrmpass + "'";
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {

                MessageBox.Show("Tebrikler! Başarılı bir şekilde giriş yaptınız.");


            }
            else
            {
                P_yanlisg.Visible = true;
            }
            dr.Close();
            Pharma phrm = new Pharma();
            SqlCommand cmd1 = new SqlCommand();
            cmd1.Connection = cnn;
            cmd1.CommandText = "SELECT Eczane_ID FROM ECZANE WHERE Eczane_Kullanici_Adi='" + phrmusername + "' AND Eczane_Password='" + phrmpass + "'";
            int eczaneid = (int)cmd1.ExecuteScalar();
            phrm.phrmid = eczaneid.ToString();
            this.Hide();
            phrm.ShowDialog();
            cnn.Close();
        }
        private Point mouseOffset;
        private bool isMouseDown = false;
        private void LoginP_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void LoginP_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void LoginP_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }

        private void P_kay_Click(object sender, EventArgs e)
        {
            RegisterP logp = new RegisterP();
            this.Hide();
            logp.ShowDialog();
        }
    }
}
