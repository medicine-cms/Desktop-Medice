﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using TEZ.Data;
using System.IO.Ports;

namespace TEZ
{
    public partial class Pharma : Form
    {
        public Pharma()
        {
            InitializeComponent();
            Load += new EventHandler(Pharma_Load);
        }
        public string phrmid { get; set; }
        public int tagNumber;
        int hastaid;
        private void Pharma_Load(object sender, EventArgs e)
        {
            SqlConnection cnn = DBConnect.getConnection();
            cnn.Open();
            try
            {
                if (cnn.State != ConnectionState.Open)
                {
                    MessageBox.Show("Fail");
                }
                else
                {
                    MessageBox.Show("Success");
                    if (!serialPort1.IsOpen)
                    {
                        serialPort1.Open();
                        MessageBox.Show("Kart Okuyucuya başarılı bir şekilde Bağlanıldı.");
                    }
                    else
                    {
                    }
                }
            }
            catch { MessageBox.Show("Bağlantı hatası oluştu"); }

            try
            {
                int idpharma = Int32.Parse(phrmid);
                string sqlSelectPharma = "SELECT * FROM ECZANE WHERE Eczane_ID= '" + idpharma + "'";
                SqlCommand cmd3 = new SqlCommand(sqlSelectPharma, cnn);
                SqlDataReader dr2 = cmd3.ExecuteReader();
                if (dr2.Read())
                {

                    pharmaname.Text = (dr2["Eczane_Adi"].ToString());


                }
                dr2.Close();
                cnn.Close();
            }
            catch { MessageBox.Show("Girişte problem oldu tekrar giriş yapınız"); }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            loginP logp = new loginP();
            logp.ShowDialog();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            this.Hide();
            log.ShowDialog();
            this.Visible = false;
        }
        
        public void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {

            Control.CheckForIllegalCrossThreadCalls = false;
            string startsWith = "The tag's number is:";
            SerialPort sp = (SerialPort)sender;
            string indata = sp.ReadExisting();
            tagNumber = 0;
            try
            {
                indata.Split(Environment.NewLine.ToCharArray())      // split on newline chars
                      .FirstOrDefault(s => s.Contains(startsWith)) // get first string matching pattern above 
                      .Split(':')                                    // split on ':'
                      .FirstOrDefault(x => int.TryParse(x, out tagNumber));  // return first successful try parse
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }
          
            
            
            try
            {
                // Receive Data
                SqlConnection cnn = DBConnect.getConnection();
                cnn.Open();
                string sqlSelectHastaid = "SELECT Hasta_ID FROM KART WHERE KART_ID='" + tagNumber + "' ";
                SqlCommand cmd1 = new SqlCommand(sqlSelectHastaid, cnn);
                hastaid = (int)cmd1.ExecuteScalar();
              
                string sqlSelectQuery = "SELECT * FROM HASTA WHERE Hasta_ID= '" + hastaid + "'";
                SqlCommand cmd = new SqlCommand(sqlSelectQuery, cnn);
                SqlDataReader dr = cmd.ExecuteReader();
                int yas;
                DateTime dogumtarihi;
                
                if (dr.Read())
                {
                    lbla.Visible = true;
                    lbly.Visible = true;
                    lblk.Visible = true;
                    dogumtarihi = Convert.ToDateTime(dr["Hasta_Dogum_Tarihi"]);
                    yas = DateTime.Now.Year - dogumtarihi.Year; // Calculate age
                    lblTc.Text += (dr["Hasta_TC_Kimlik_No"].ToString());
                    lblAd.Text = (dr["Hasta_Ad"].ToString());
                    lblSoyad.Text += (dr["Hasta_Soyad"].ToString());
                    lblYaş.Text += yas.ToString();
                    lblAlerji.Text += (dr["Alerji"].ToString());
                    lblKro.Text += (dr["Kronik_Hastalik"].ToString());

                }
                dr.Close();
                cnn.Close();
            }
            catch
            {
                //MessageBox.Show("Hasta kartı okutunuz!!!"); 
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int seçilensatır = Convert.ToInt32((dataGridView1.CurrentRow.Cells[0].Value));
            SqlConnection cnn = DBConnect.getConnection();
            cnn.Open();
            string durumgüncelleme = "UPDATE ILAC SET durum=@durum WHERE Ilac_ID='" + seçilensatır + "'";
            SqlCommand cmd = new SqlCommand(durumgüncelleme, cnn);
            cmd.Parameters.AddWithValue("@durum", 1);
            cmd.ExecuteNonQuery();
            cnn.Close();
            dataGridView1.DefaultCellStyle.SelectionBackColor = Color.SlateGray;
            MessageBox.Show("Güncellendi.");


        }

        private void button4_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            Login login = new Login();
            this.Close();
            login.ShowDialog();

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            SqlConnection cnn = DBConnect.getConnection();
            cnn.Open();
            
            //hasta id sini çektim ona göre ilaç tablosu dolacak.
            try
            {
                string ilac = "SELECT Ilac_ID,Ilac_Adi,Verildigi_Tarih,Max_Kullanim_Suresi,Kullanim_Araligi,Kullanim_Dozu,Kullanim_Sekli FROM ILAC WHERE Hasta_ID = '" + hastaid + "' AND durum=0";
                SqlCommand cmd2 = new SqlCommand(ilac, cnn);
                SqlDataAdapter da = new SqlDataAdapter(cmd2);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                dataGridView1.Columns["Ilac_ID"].Visible = false;
            }
            catch { MessageBox.Show("Hasta kartı okutunuz."); }
            cnn.Close();

        }
        private Point mouseOffset;
        private bool isMouseDown = false;

        private void Pharma_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void Pharma_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void Pharma_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }
    }
}
