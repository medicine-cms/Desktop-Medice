﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using TEZ.Data;

namespace TEZ
{
    public partial class loginA : Form
    {
        
        Admin adm = new Admin();
        public loginA()
        {
            
            InitializeComponent();
            textBox2.PasswordChar = '*';
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string adminid = textBox2.Text;
            int adminidint;
            bool res = int.TryParse(adminid, out adminidint);            
            string adminpass = textBox2.Text;
            SqlConnection cnn = DBConnect.getConnection();
            SqlCommand cmd;
            SqlDataReader dr;
            cmd = new SqlCommand();
            cnn.Open();
            cmd.Connection = cnn;
            cmd.CommandText = "SELECT * FROM ADMIN where Admin_ID='" + adminidint + "' AND Admin_Password='" + adminpass + "'";
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                MessageBox.Show("Tebrikler! Başarılı bir şekilde giriş yaptınız.");                
                adm.ShowDialog();
                this.Hide();
                this.Visible = false;
            }
            else
            {
                label2.Visible = true;                
            }
            cnn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            this.Hide();
            log.ShowDialog();
        }
    }
}
