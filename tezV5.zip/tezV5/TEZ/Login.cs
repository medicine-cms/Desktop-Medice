﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TEZ
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }



        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            LogRegA loga = new LogRegA();
            this.Hide();
            loga.ShowDialog();

        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            LogRegD logd = new LogRegD();
            this.Hide();
            logd.ShowDialog();

        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            LogRegP logp = new LogRegP();
            this.Hide();
            logp.ShowDialog();

        }
        private Point mouseOffset;
        private bool isMouseDown = false;

        private void Login_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void Login_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void Login_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }
    }
    }

