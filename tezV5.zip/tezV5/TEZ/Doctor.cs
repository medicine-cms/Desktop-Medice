﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using TEZ.Data;
using System.IO.Ports;

namespace TEZ
{
    public partial class Doctor : Form
    {
        public Doctor()
        {            
            InitializeComponent();
            Load += new EventHandler(Doctor_Load);
            
        }
        public int tagNumber;
        public int hastaid ;
        int doktortc;
        public string doctc { get; set; } //doc id yi doktor giriş sayfasından çekme işlemi
        private void Doctor_Load(object sender, EventArgs e)
        {
            lbla.Visible = false;
            lbly.Visible = false;
            lblk.Visible = false;
            try
            {
                SqlConnection cnn = DBConnect.getConnection();
                cnn.Open();

                if (cnn.State != ConnectionState.Open)
                {
                    //MessageBox.Show("Fail");
                }
                else
                {
                    //MessageBox.Show("Success");
                    if (!serialPort1.IsOpen)
                    {
                        serialPort1.Open();
                       // MessageBox.Show("kart ok");

                    }
                }
                doktortc = Int32.Parse(doctc);
                string sqlSelectDoktor = "SELECT * FROM DOKTOR WHERE TC_Numara= '" + doktortc + "'";
                SqlCommand cmd2 = new SqlCommand(sqlSelectDoktor, cnn);
                SqlDataReader dr2 = cmd2.ExecuteReader();
                if (dr2.Read())
                {

                    lbldocad.Text += (dr2["Doktor_Unvan"].ToString());
                    lbldocad.Text += (dr2["Doktor_Brans"].ToString());
                    lbldocad.Text += (dr2["Doktor_Ad"].ToString());
                    lbldocad.Text += (dr2["Doktor_Soyad"].ToString());

                }
                dr2.Close();
                cnn.Close();
            }
            catch { MessageBox.Show("Tekrar giriş yapınız"); }            
        }
        
        private void serialPort1_DataReceived_1(object sender, SerialDataReceivedEventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            string startsWith = "The tag's number is:";
            SerialPort sp = (SerialPort)sender;
            string indata = sp.ReadExisting();
            tagNumber = 0;
            try
            {
                indata.Split(Environment.NewLine.ToCharArray())      // split on newline chars
                      .FirstOrDefault(s => s.Contains(startsWith)) // get first string matching pattern above 
                      .Split(':')                                    // split on ':'
                      .FirstOrDefault(x => int.TryParse(x, out tagNumber));  // return first successful try parse
            }
            catch (Exception ex) { 
                //MessageBox.Show("Kart okuma başarısız oldu tekrar deneyin"); 
            }
            //MessageBox.Show(tagNumber.ToString());

            // Receive Data
            try
            {
                SqlConnection cnn = DBConnect.getConnection();
                cnn.Open();
                string sqlSelectQuery = "SELECT * FROM HASTA WHERE KART_ID= '" + tagNumber + "'";
                SqlCommand cmd = new SqlCommand(sqlSelectQuery, cnn);
                SqlDataReader dr = cmd.ExecuteReader();
                int yas;
                DateTime dogumtarihi;

                if (dr.Read())
                {

                    lbla.Visible = true;
                    lbly.Visible = true;
                    lblk.Visible = true;
                    dogumtarihi = Convert.ToDateTime(dr["Hasta_Dogum_Tarihi"]);
                    yas = DateTime.Now.Year - dogumtarihi.Year; // Calculate age
                    lblTc.Text += (dr["Hasta_TC_Kimlik_No"].ToString());
                    lblAd.Text = (dr["Hasta_Ad"].ToString());
                    lblSoyad.Text += (dr["Hasta_Soyad"].ToString());
                    lblYaş.Text += yas.ToString();
                    lblAlerji.Text += (dr["Alerji"].ToString());
                    lblKro.Text += (dr["Kronik_Hastalik"].ToString());


                }
                dr.Close();
                cnn.Close();
            }
            catch { MessageBox.Show("Kartı tekrar okutunuz"); }
        }

      

        private void button1_Click(object sender, EventArgs e)
        {
            loginD logd = new loginD();
            logd.ShowDialog();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            this.Hide();
            log.ShowDialog();
        }

       
        private void button4_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            log.ShowDialog();
            this.Hide();
        }

      

        private void btnilaçekle_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = DBConnect.getConnection();
                cnn.Open();
                string sqlSelectHastaid = "SELECT Hasta_ID FROM HASTA WHERE KART_ID='" + tagNumber + "' ";
                SqlCommand cmd1 = new SqlCommand(sqlSelectHastaid, cnn);
                hastaid = (int)cmd1.ExecuteScalar();
                string hastaidalerji = hastaid.ToString();
                Alerji alerji = new Alerji();
                alerji.hastaidalerji = hastaidalerji;
                alerji.ShowDialog();
            }
            catch { MessageBox.Show("Hata oluştu"); }
           
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = DBConnect.getConnection();
                cnn.Open();
                
                string sqlSelectHastaid = "SELECT Hasta_ID FROM HASTA WHERE KART_ID='" + tagNumber + "' ";
                SqlCommand cmd1 = new SqlCommand(sqlSelectHastaid, cnn);
                hastaid = (int)cmd1.ExecuteScalar();

                string sqlSelectDocid = "SELECT Doktor_ID FROM DOKTOR WHERE TC_Numara='" + doctc + "' ";
                SqlCommand cmd2 = new SqlCommand(sqlSelectHastaid, cnn);
                int doctorid = (int)cmd2.ExecuteScalar();

                //ilaç ekleme bölümü
                SqlCommand cmd3 = new SqlCommand("INSERT INTO ILAC (Ilac_Adi,Verildigi_Tarih,Max_Kullanim_Suresi,Kullanim_Araligi,Kullanim_Dozu,Kullanim_Sekli,Doktor_ID,Hasta_ID) VALUES (@Ilac_Adi,@Verildigi_Tarih,@Max_Kullanim_Suresi,@Kullanim_Araligi,@Kullanim_Dozu,@Kullanim_Sekli,@Doktor_ID,@Hasta_ID)", cnn);
                cmd3.Parameters.AddWithValue("@Ilac_Adi", txtİlaçAdı.Text);
                cmd3.Parameters.AddWithValue("@Verildigi_Tarih", DateTime.Now.AddDays(0));
                cmd3.Parameters.AddWithValue("@Max_Kullanim_Suresi", maxks.SelectedItem);
                cmd3.Parameters.AddWithValue("@Kullanim_Araligi", gks.SelectedItem);
                cmd3.Parameters.AddWithValue("@Kullanim_Dozu", ilacdozu.SelectedItem);
                cmd3.Parameters.AddWithValue("@Kullanim_Sekli", txtKullŞekli.Text);
                cmd3.Parameters.AddWithValue("@Doktor_ID", doctorid);
                cmd3.Parameters.AddWithValue("@Hasta_ID", hastaid);
                int a = cmd3.ExecuteNonQuery();
                cnn.Close();
                if (a == 0)
                {
                    MessageBox.Show("ilaç ekleme başarısız.");
                }
                else
                {
                    MessageBox.Show("ilaç ekleme başarılı.");
                    Doctor_Load(null, null);

                }
            }
            catch { MessageBox.Show("İlaç eklerken hata oluştu tekrar deneyin"); }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            serialPort1.Close();
            Login login = new Login();
            this.Close();
            login.ShowDialog();
               
        }
        private Point mouseOffset;
        private bool isMouseDown = false;

        private void Doctor_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }

        }

        private void Doctor_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void Doctor_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }
    }
}
