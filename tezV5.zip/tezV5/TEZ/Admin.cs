﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TEZ.Data;

namespace TEZ
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
            Load += new EventHandler(Admin_Load);
        }
        public string adminid { get; set; }
        public int tagNumber;
        private void Admin_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = DBConnect.getConnection();
                cnn.Open();

                if (cnn.State != ConnectionState.Open)
                {
                    MessageBox.Show("Fail");
                }
                else
                {
                    //MessageBox.Show("Success");
                    if (!serialPort1.IsOpen)
                    {
                        serialPort1.Open();
                        //MessageBox.Show("Kart Okuyucuya başarılı bir şekilde Bağlanıldı.");
                    }
                }
                cnn.Close();
            }
            catch { MessageBox.Show("Tekrar giriş yapınız"); }
        }



        private void serialPort1_DataReceived(object sender,SerialDataReceivedEventArgs e )
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            string startsWith = "The tag's number is:";
            SerialPort sp = (SerialPort)sender;
            string indata = sp.ReadExisting();
            tagNumber = 0;
            try
            {
                indata.Split(Environment.NewLine.ToCharArray())      // split on newline chars
                      .FirstOrDefault(s => s.Contains(startsWith)) // get first string matching pattern above 
                      .Split(':')                                    // split on ':'
                      .FirstOrDefault(x => int.TryParse(x, out tagNumber));  // return first successful try parse
                
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Kart okuma başarısız oldu tekrar deneyin"); 
            }          
            
            MessageBox.Show(tagNumber.ToString());
            txtKartid.Text = tagNumber.ToString();
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = DBConnect.getConnection();
                cnn.Open();
                long hastatc = long.Parse(txtHastaId.Text);


                string sqlSelectHastaid = "SELECT Hasta_ID FROM HASTA WHERE Hasta_TC_Kimlik_No='" + hastatc + "' ";
                SqlCommand cmd1 = new SqlCommand(sqlSelectHastaid, cnn);
                int hastaid = (int)cmd1.ExecuteScalar();
                int tg = Convert.ToInt32(txtKartid.Text);
                
                SqlCommand cmdtagnumber = new SqlCommand("INSERT INTO KART (Kart_ID,Hasta_ID) VALUES (@Kart_ID,@Hasta_ID)", cnn);
                cmdtagnumber.Parameters.AddWithValue("@Kart_ID", tg);
                cmdtagnumber.Parameters.AddWithValue("@Hasta_ID", hastaid);
                int a = cmdtagnumber.ExecuteNonQuery();

                if (a == 0)
                {
                    MessageBox.Show("Tgnumber ekleme başarısız.");
                }
                else
                {
                    MessageBox.Show("Tgnumber ekleme başarılı.");


                }
                string hastagüncelleme = "UPDATE HASTA SET Kart_ID=@Kart_ID WHERE Hasta_ID='" + hastaid + "'";
                SqlCommand cmd = new SqlCommand(hastagüncelleme, cnn);
                cmd.Parameters.AddWithValue("@Kart_ID", tagNumber);
                cmd.ExecuteNonQuery();
                cnn.Close();
            }
            catch { MessageBox.Show("Hata oluştu tekrar deneyin"); }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            loginA loga = new loginA();
            this.Hide();
            loga.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            Login log = new Login();
            this.Close();
            log.ShowDialog();

        }
        private Point mouseOffset;
        private bool isMouseDown = false;

        private void Admin_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void Admin_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void Admin_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }
    }
}
