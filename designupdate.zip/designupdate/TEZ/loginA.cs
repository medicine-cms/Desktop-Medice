﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TEZ
{
    public partial class loginA : Form
    {
        Admin adm = new Admin();
        public loginA()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            adm.ShowDialog();
            this.Hide();
            this.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            this.Hide();
            log.ShowDialog();
        }
    }
}
