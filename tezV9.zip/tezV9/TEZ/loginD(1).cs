﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using TEZ.Data;

namespace TEZ
{
    public partial class loginD : Form
    {
        Doctor dctr = new Doctor();
        public loginD()
        {
            InitializeComponent();
            textBox2.PasswordChar = '*';
        }

        private void bunifuCustomLabel1_Click(object sender, EventArgs e)
        {

        }

        private void loginD_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dctr.ShowDialog();
            this.Hide();
            this.Visible = false;
            string docid = textBox2.Text;
            int docidint;
            bool res = int.TryParse(docid, out docidint);
            string docpass = textBox2.Text;
            SqlConnection cnn = DBConnect.getConnection();
            SqlCommand cmd;
            SqlDataReader dr;
            cmd = new SqlCommand();
            cnn.Open();
            cmd.Connection = cnn;
            cmd.CommandText = "SELECT * FROM DOKTOR where Doktor_ID='" + docidint + "' AND Doktor_Password='" + docpass + "'";
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                MessageBox.Show("Tebrikler! Başarılı bir şekilde giriş yaptınız.");
                dctr.ShowDialog();
                this.Hide();
                this.Visible = false;
            }
            else
            {
                label2.Visible = true;
            }
            cnn.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            this.Hide();
            log.ShowDialog();
        }
    }
}
