﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using TEZ.Data;

namespace TEZ
{
    public partial class RegisterP : Form
    {
        public RegisterP()
        {
            InitializeComponent();
            
        }
        SqlConnection cnn = DBConnect.getConnection();
        private void P_kay_Click(object sender, EventArgs e)
        {
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();

                string kayit = "insert into ECZANE(Eczane_Adi,Eczane_Password,Eczane_Kullanici_Adi) values (@Eczane_Adi,@Eczane_Password,@Eczane_Kullanici_Adi)";

                SqlCommand komut = new SqlCommand(kayit, cnn);

                komut.Parameters.AddWithValue("@Eczane_Adi", P_ad.Text);
                komut.Parameters.AddWithValue("@Eczane_Password", P_sifre.Text);
                komut.Parameters.AddWithValue("@Eczane_Kullanici_Adi", P_KullanıcıAdı.Text);

                komut.ExecuteNonQuery();

                cnn.Close();
                MessageBox.Show("Kayıt işlemi gerçekleşti.");
                RegisterP login = new RegisterP();
                login.Show();
                login.Hide();
            }
            catch (Exception hata)
            {
                P_yanlisk.Visible = true;
            }
        }

       

        private void main_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            this.Hide();
            log.ShowDialog();
        }
        private Point mouseOffset;
        private bool isMouseDown = false;

        private void LogRegP_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void LogRegP_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void LogRegP_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ForgotPassPharma forgotpass = new ForgotPassPharma();
            forgotpass.Show();
            this.Hide();
        }

        private void panel4_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void panel4_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void panel4_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }
    }
}
