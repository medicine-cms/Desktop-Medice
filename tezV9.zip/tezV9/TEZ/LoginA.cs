﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using TEZ.Data;


namespace TEZ
{
    public partial class LoginA : Form
    {
        Admin adm = new Admin();
       
        public LoginA()
        {
            InitializeComponent();
            A_pass.PasswordChar = '*';
        }
        SqlConnection cnn = DBConnect.getConnection();

        private void main_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            this.Hide();
            log.ShowDialog();
        }

        private void A_gir_Click(object sender, EventArgs e)
        {
            try
            {
                string admintc = A_id.Text;
                long admintcint;
                bool res = long.TryParse(admintc, out admintcint);
                string adminpass = A_pass.Text;
                SqlConnection cnn = DBConnect.getConnection();
                SqlCommand cmd;
                SqlDataReader dr;
                cmd = new SqlCommand();
                cnn.Open();
                cmd.Connection = cnn;
                cmd.CommandText = "SELECT * FROM ADMIN where TC_Numara='" + admintcint + "' AND Admin_Password='" + adminpass + "'";
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {

                    MessageBox.Show("Tebrikler! Başarılı bir şekilde giriş yaptınız.");

                }
                else
                {
                    A_yanlisg.Visible = true;
                }
                dr.Close();

                SqlCommand cmd1 = new SqlCommand();
                cmd1.Connection = cnn;
                cmd1.CommandText = "SELECT Admin_ID FROM ADMIN WHERE TC_Numara='" + admintcint + "' AND Admin_Password='" + adminpass + "'";
                int adminidsi = (int)cmd1.ExecuteScalar();
                adm.adminid = adminidsi.ToString();
                adm.ShowDialog();
                this.Hide();
                this.Visible = false;

                cnn.Close();
            }
            catch { MessageBox.Show(""); }
        }
        private Point mouseOffset;
        private bool isMouseDown = false;

        private void LoginA_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void LoginA_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void LoginA_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }
    }
}
