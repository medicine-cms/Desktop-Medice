﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TEZ.Data;

namespace TEZ
{
    public partial class Alerji : Form
    {
        public Alerji()
        {
            InitializeComponent();

        }
        
        public string hastaidalerji { get; set; }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void Alerji_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = DBConnect.getConnection();
                cnn.Open();
                int hastaidint = Int32.Parse(hastaidalerji);
                string sqlSelectQuery = "SELECT * FROM HASTA WHERE HASTA_ID= '" + hastaidint + "'";
                SqlCommand cmd = new SqlCommand(sqlSelectQuery, cnn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {

                    lbltc.Text = (dr["Hasta_TC_Kimlik_No"].ToString());
                    lblAd.Text = (dr["Hasta_Ad"].ToString());
                    lblSoyad.Text = (dr["Hasta_Soyad"].ToString());

                }              
                dr.Close();
                cnn.Close();
            }
            catch { MessageBox.Show("Hata oluştu tekrar deneyin"); }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = DBConnect.getConnection();
                cnn.Open();

                int hastaidint = Int32.Parse(hastaidalerji);
                if(txtAlerji.Text  != null )
                {
                    string Alerjigüncelleme = "UPDATE HASTA SET Alerji=@Alerji WHERE HASTA_ID='" + hastaidint + "'";
                    SqlCommand cmd = new SqlCommand(Alerjigüncelleme, cnn);
                    cmd.Parameters.AddWithValue("@Alerji", txtAlerji.Text);                    
                    cmd.ExecuteNonQuery();
                }
                if (txtKh != null)
                {
                    string kronikhastalıkgüncelleme = "UPDATE HASTA SET Kronik_Hastalik=@Kronik_Hastalik WHERE HASTA_ID='" + hastaidint + "'";
                    SqlCommand cmd1 = new SqlCommand(kronikhastalıkgüncelleme, cnn);
                    
                    cmd1.Parameters.AddWithValue("@Kronik_Hastalik", txtKh.Text);
                    cmd1.ExecuteNonQuery();
                }
                else { }
                
                cnn.Close();

                MessageBox.Show("Güncellendi.");
            }
            catch { MessageBox.Show("Hasta bilgilerini güncellerken hata oluştu tekrar deneyin"); }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private Point mouseOffset;
        private bool isMouseDown = false;

        private void Alerji_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }

        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void Alerji_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void Alerji_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }
    }
}
