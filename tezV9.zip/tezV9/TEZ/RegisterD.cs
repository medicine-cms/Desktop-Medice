﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using TEZ.Data;

namespace TEZ
{

   

    public partial class RegisterD : Form
    {
        long tc;
        long serino;
        
        public RegisterD()
        {
            InitializeComponent();
            
        }
        SqlConnection cnn = DBConnect.getConnection();

        private void main_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            this.Hide();
            log.ShowDialog();
        }

        private void D_kay_Click(object sender, EventArgs e)
        {
            try
            {
                tc = long.Parse(D_tc.Text);
                serino = long.Parse(D_serino.Text);
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();

                string kayit = "insert into DOKTOR(Doktor_Ad,Doktor_Soyad,Doktor_Password,TC_Numara,Doktor_SeriNo) values (@Doktor_Ad,@Doktor_Soyad,@Doktor_Password,@TC_Numara,@Doktor_SeriNo)";

                SqlCommand komut = new SqlCommand(kayit, cnn);

                komut.Parameters.AddWithValue("@Doktor_Ad", D_ad.Text);
                komut.Parameters.AddWithValue("@Doktor_Soyad", D_soyad.Text);
                komut.Parameters.AddWithValue("@Doktor_Password", D_sifre.Text);
                komut.Parameters.AddWithValue("@TC_Numara", tc);
                komut.Parameters.AddWithValue("@Doktor_SeriNo", serino);
                komut.ExecuteNonQuery();
               
                cnn.Close();
                MessageBox.Show("Kayıt işlemi gerçekleşti.");
                RegisterD login = new RegisterD();
                login.Show();
                this.Hide();
            }
            catch (Exception hata)
            {
                D_yanlisk.Visible = true;
            }
        }

        private Point mouseOffset;
        private bool isMouseDown = false;

        private void LogRegD_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void LogRegD_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void LogRegD_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ForgotPassDoctor forgotpass = new ForgotPassDoctor();
            forgotpass.Show();
            this.Hide();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }
    }
    }
   
  

