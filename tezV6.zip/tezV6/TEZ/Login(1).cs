﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TEZ
{
    public partial class Login : Form
    {
        
       
        

        public Login()
        {
            InitializeComponent();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            loginA loga = new loginA();
            this.Hide();
             loga.ShowDialog();
            this.Visible = false;
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            loginD logd = new loginD();
            logd.ShowDialog();
            this.Hide();
            this.Visible = false;
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            loginP logp = new loginP();
            logp.ShowDialog();
            this.Hide();
            this.Visible = false;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
