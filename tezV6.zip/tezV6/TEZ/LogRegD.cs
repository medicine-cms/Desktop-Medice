﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using TEZ.Data;

namespace TEZ
{

   

    public partial class LogRegD : Form
    {
        Doctor dctr = new Doctor();
        public LogRegD()
        {
            InitializeComponent();
            D_pass.PasswordChar = '*';
        }
        SqlConnection cnn = DBConnect.getConnection();

        private void D_gir_Click(object sender, EventArgs e)
        {
            try
            {
                string doctc = D_id.Text;
                int doctcint;
                bool res = int.TryParse(doctc, out doctcint);
                string docpass = D_pass.Text;
                SqlConnection cnn = DBConnect.getConnection();
                SqlCommand cmd;
                SqlDataReader dr;
                cmd = new SqlCommand();
                cnn.Open();
                cmd.Connection = cnn;
                cmd.CommandText = "SELECT * FROM DOKTOR where TC_Numara='" + doctcint + "' AND Doktor_Password='" + docpass + "'";
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    dctr.doctc = D_id.Text;
                    MessageBox.Show("Tebrikler! Başarılı bir şekilde giriş yaptınız.");
                    this.Hide();
                    dctr.ShowDialog();

                }
                else
                {
                    D_yanlisg.Visible = true;
                }
                cnn.Close();
            }
            catch { MessageBox.Show(""); }
        }

        private void main_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            this.Hide();
            log.ShowDialog();
        }

        private void D_kay_Click(object sender, EventArgs e)
        {
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();

                string kayit = "insert into DOKTOR(TC_Numara,Doktor_Ad,Doktor_Soyad,Doktor_Password) values (@TC_Numara,@Doktor_Ad,@Doktor_Soyad,@Doktor_Password)";

                SqlCommand komut = new SqlCommand(kayit, cnn);

                komut.Parameters.AddWithValue("@TC_Numara", D_TC.Text);
                komut.Parameters.AddWithValue("@Doktor_Ad", D_ad.Text);
                komut.Parameters.AddWithValue("@Doktor_Soyad", D_soyad.Text);
                komut.Parameters.AddWithValue("@Doktor_Password", D_sifre.Text);


                komut.ExecuteNonQuery();
               
                cnn.Close();
                MessageBox.Show("Kayıt işlemi gerçekleşti.");
            }
            catch (Exception hata)
            {
                D_yanlisk.Visible = true;
            }
        }

        private Point mouseOffset;
        private bool isMouseDown = false;

        private void LogRegD_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void LogRegD_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void LogRegD_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }
    }
    }
   
  

