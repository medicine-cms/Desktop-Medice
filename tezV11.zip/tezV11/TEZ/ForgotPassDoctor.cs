﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TEZ.Data;

namespace TEZ
{
    public partial class ForgotPassDoctor : Form
    {
        public ForgotPassDoctor()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void main_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Close();
            login.ShowDialog();
        }
        private Point mouseOffset;
        private bool isMouseDown = false;

        private void ForgotPassDoctor_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void ForgotPassDoctor_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void ForgotPassDoctor_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            A_yanlisg.Visible = false;
            try
            { 
                SqlConnection cnn = DBConnect.getConnection();
                cnn.Open();

                if (cnn.State != ConnectionState.Open)
                {
                    MessageBox.Show("Fail");
                }

                string tc = txtTc.Text;
                long tcint = long.Parse(tc);
                //bool res = long.TryParse(tc, out tcint);
                string serino = txtSerino.Text;
                long serinoint;
                bool res1 = long.TryParse(serino, out serinoint);
                SqlCommand cmd;
                SqlDataReader dr;
                cmd = new SqlCommand();
                cmd.Connection = cnn;
                cmd.CommandText = "SELECT * FROM DOKTOR where TC_Numara='" + tcint + "' AND Doktor_SeriNo='" + serinoint + "'";
                dr = cmd.ExecuteReader();
                int durum = 0;
                if (dr.Read())
                {
                    durum = 1;

                }
                else
                {
                    A_yanlisg.Visible = true;
                }
                dr.Close();
                if (durum == 1)
                {
                    string pass = "SELECT Doktor_Password FROM DOKTOR WHERE TC_Numara='" + tcint + "'";
                    SqlCommand cmd1 = new SqlCommand(pass, cnn);
                    string password = (string)cmd1.ExecuteScalar();                
                    MessageBox.Show("Şifreniz : " + password);
                }

                }
            catch { };
        }
    }
}
