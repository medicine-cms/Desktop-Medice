﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TEZ.Data;

namespace TEZ
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
            Load += new EventHandler(Admin_Load);
        }
        public string adminid { get; set; }
        long tagNumber;
        public int admin;
        private void Admin_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = DBConnect.getConnection();
                cnn.Open();

                if (cnn.State != ConnectionState.Open)
                {
                    MessageBox.Show("Fail");
                }
                else
                {
                    //MessageBox.Show("Success");
                    if (!serialPort1.IsOpen)
                    {
                        serialPort1.Open();
                        //MessageBox.Show("Kart Okuyucuya başarılı bir şekilde Bağlanıldı.");
                    }
                }
                
                admin = Int32.Parse(adminid);
                string sqlSelectAdmin = "SELECT * FROM ADMIN WHERE Admin_ID = '" + admin + "'";
                SqlCommand cmd = new SqlCommand(sqlSelectAdmin, cnn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    adminAd.Text = (dr["Admin_Ad"].ToString());
                    //adminAd.Text += " ";
                    adminSoyad.Text = (dr["Admin_Soyad"].ToString());
                 

                }
                dr.Close();
                cnn.Close();
            }
            catch { MessageBox.Show("Tekrar giriş yapınız"); }
        }



        private void serialPort1_DataReceived(object sender,SerialDataReceivedEventArgs e )
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            string Number = serialPort1.ReadLine();
            tagNumber = Convert.ToInt32(Number);            
            txtKartid.Text = tagNumber.ToString();
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = DBConnect.getConnection();
                cnn.Open();
                long hastatc = long.Parse(txtHastaId.Text);


                string sqlSelectHastaid = "SELECT Hasta_ID FROM HASTA WHERE Hasta_TC_Kimlik_No='" + hastatc + "' ";
                SqlCommand cmd1 = new SqlCommand(sqlSelectHastaid, cnn);
                int hastaid = (int)cmd1.ExecuteScalar();
                int tg = Convert.ToInt32(txtKartid.Text);
                
                SqlCommand cmdtagnumber = new SqlCommand("INSERT INTO KART (Kart_ID,Hasta_ID) VALUES (@Kart_ID,@Hasta_ID)", cnn);
                cmdtagnumber.Parameters.AddWithValue("@Kart_ID", tg);
                cmdtagnumber.Parameters.AddWithValue("@Hasta_ID", hastaid);
                int a = cmdtagnumber.ExecuteNonQuery();

                if (a == 0)
                {
                    MessageBox.Show("Tgnumber ekleme başarısız.");
                }
                else
                {
                    MessageBox.Show("Tgnumber ekleme başarılı.");


                }
                string hastagüncelleme = "UPDATE HASTA SET Kart_ID=@Kart_ID WHERE Hasta_ID='" + hastaid + "'";
                SqlCommand cmd = new SqlCommand(hastagüncelleme, cnn);
                cmd.Parameters.AddWithValue("@Kart_ID", tagNumber);
                cmd.ExecuteNonQuery();
                cnn.Close();
            }
            catch { MessageBox.Show("Hata oluştu tekrar deneyin"); }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            /*loginA loga = new loginA();
            this.Hide();
            loga.ShowDialog();*/
        }

        private void button2_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            Login log = new Login();
            this.Close();
            log.ShowDialog();

        }
        private Point mouseOffset;
        private bool isMouseDown = false;

        private void Admin_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void Admin_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void Admin_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }

        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }
    }
}
