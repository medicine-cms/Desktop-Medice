﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TEZ.Data;

namespace TEZ
{
    public partial class ForgotPassPharma : Form
    {
        public ForgotPassPharma()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void A_yanlisg_Click(object sender, EventArgs e)
        {

        }

        private void main_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Close();
            login.ShowDialog();
        }
        private Point mouseOffset;
        private bool isMouseDown = false;
        private void ForgotPassPharma_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;

            int yOffset;

            if

            (e.Button == MouseButtons.Left)

            {

                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;

                yOffset = -e.Y - SystemInformation.CaptionHeight -

SystemInformation.FrameBorderSize.Height;

                mouseOffset = new Point(xOffset, yOffset);

                isMouseDown = true;

            }
        }

        private void ForgotPassPharma_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)

            {

                Point mousePos = Control.MousePosition;

                mousePos.Offset(mouseOffset.X, mouseOffset.Y);

                Location = mousePos;

            }
        }

        private void ForgotPassPharma_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)

            {

                isMouseDown = false;

            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            A_yanlisg.Visible = false;
            try
            {
                SqlConnection cnn = DBConnect.getConnection();
                cnn.Open();

                if (cnn.State != ConnectionState.Open)
                {
                    MessageBox.Show("Fail");
                }

                string kullaniciAdi = txtKullanıcıAdi.Text;


                SqlCommand cmd;
                SqlDataReader dr;
                cmd = new SqlCommand();
                cmd.Connection = cnn;
                cmd.CommandText = "SELECT * FROM ECZANE where Eczane_Kullanici_Adi='" + kullaniciAdi + "'";
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string pass = "SELECT Eczane_Password WHERE Eczane_Kullanici_Adi='" + kullaniciAdi + "'";
                    SqlCommand cmd1 = new SqlCommand(pass, cnn);
                    string password = (string)cmd1.ExecuteScalar();
                    MessageBox.Show("Şifereniz : " + password);

                }
                else
                {
                    A_yanlisg.Visible = true;
                }
            }
            catch { };
        }
    }
}
