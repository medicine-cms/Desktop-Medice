﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TEZ.Data;

namespace TEZ
{
    public partial class ForgotPassPharma : Form
    {
        public ForgotPassPharma()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            A_yanlisg.Visible = false;
            try
            {
                SqlConnection cnn = DBConnect.getConnection();
                cnn.Open();

                if (cnn.State != ConnectionState.Open)
                {
                    MessageBox.Show("Fail");
                }

                string kullaniciAdi = txtKullanıcıAdi.Text;         
                      
                
                SqlCommand cmd;
                SqlDataReader dr;
                cmd = new SqlCommand();
                cmd.Connection = cnn;
                cmd.CommandText = "SELECT * FROM ECZANE where Eczane_Kullanici_Adi='" + kullaniciAdi + "'";
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string pass = "SELECT Eczane_Password WHERE Eczane_Kullanici_Adi='" + kullaniciAdi + "'";
                    SqlCommand cmd1 = new SqlCommand(pass, cnn);
                    int password = (int)cmd1.ExecuteScalar();
                    MessageBox.Show("Şifereniz : " + password);

                }
                else
                {
                    A_yanlisg.Visible = true;
                }
            }
            catch { };
        }
    }
}
