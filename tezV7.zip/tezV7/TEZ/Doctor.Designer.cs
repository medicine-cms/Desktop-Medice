﻿namespace TEZ
{
    partial class Doctor
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Doctor));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.bunifuFlatButton1 = new ns1.BunifuFlatButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblverildigitarih = new System.Windows.Forms.Label();
            this.ilac = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblk = new System.Windows.Forms.Label();
            this.lbla = new System.Windows.Forms.Label();
            this.lbly = new System.Windows.Forms.Label();
            this.lblKro = new System.Windows.Forms.Label();
            this.lblAlerji = new System.Windows.Forms.Label();
            this.lblTc = new System.Windows.Forms.Label();
            this.lblYaş = new System.Windows.Forms.Label();
            this.lblSoyad = new System.Windows.Forms.Label();
            this.lblAd = new System.Windows.Forms.Label();
            this.btnilaçekle = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.maxks = new System.Windows.Forms.ComboBox();
            this.gks = new System.Windows.Forms.ComboBox();
            this.ilacdozu = new System.Windows.Forms.ComboBox();
            this.txtKullŞekli = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtİlaçAdı = new System.Windows.Forms.TextBox();
            this.vScrollBar1 = new System.Windows.Forms.VScrollBar();
            this.btnKaydet = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.lbldocad = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(204)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(186, 387);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-62, -14);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(321, 108);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(230)))));
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 90);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(186, 297);
            this.panel2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.SizeNESW;
            this.label1.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(68, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "Hasta Bilgisi";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 31);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(143)))), ((int)(((byte)(179)))));
            this.panel3.Controls.Add(this.bunifuFlatButton1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 117);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(186, 180);
            this.panel3.TabIndex = 0;
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.SystemColors.ActiveCaption;
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(143)))), ((int)(((byte)(179)))));
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Reçete yaz";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton1.Iconimage")));
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(0, 3);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(143)))), ((int)(((byte)(179)))));
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(230)))));
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(170, 79);
            this.bunifuFlatButton1.TabIndex = 0;
            this.bunifuFlatButton1.Text = "Reçete yaz";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.panel4.Controls.Add(this.lblverildigitarih);
            this.panel4.Controls.Add(this.ilac);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.lblk);
            this.panel4.Controls.Add(this.lbla);
            this.panel4.Controls.Add(this.lbly);
            this.panel4.Controls.Add(this.lblKro);
            this.panel4.Controls.Add(this.lblAlerji);
            this.panel4.Controls.Add(this.lblTc);
            this.panel4.Controls.Add(this.lblYaş);
            this.panel4.Controls.Add(this.lblSoyad);
            this.panel4.Controls.Add(this.lblAd);
            this.panel4.Controls.Add(this.btnilaçekle);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel4.ForeColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(186, 93);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(669, 294);
            this.panel4.TabIndex = 1;
            // 
            // lblverildigitarih
            // 
            this.lblverildigitarih.AutoSize = true;
            this.lblverildigitarih.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblverildigitarih.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblverildigitarih.Location = new System.Drawing.Point(328, 92);
            this.lblverildigitarih.Name = "lblverildigitarih";
            this.lblverildigitarih.Size = new System.Drawing.Size(0, 19);
            this.lblverildigitarih.TabIndex = 27;
            // 
            // ilac
            // 
            this.ilac.AutoSize = true;
            this.ilac.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ilac.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ilac.Location = new System.Drawing.Point(200, 92);
            this.ilac.Name = "ilac";
            this.ilac.Size = new System.Drawing.Size(0, 19);
            this.ilac.TabIndex = 26;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label10.Location = new System.Drawing.Point(35, 92);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(141, 19);
            this.label10.TabIndex = 25;
            this.label10.Text = "Kullanılan İlaçlar";
            // 
            // lblk
            // 
            this.lblk.AutoSize = true;
            this.lblk.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblk.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblk.Location = new System.Drawing.Point(322, 61);
            this.lblk.Name = "lblk";
            this.lblk.Size = new System.Drawing.Size(142, 19);
            this.lblk.TabIndex = 11;
            this.lblk.Text = "Kronik Hastalık :  ";
            // 
            // lbla
            // 
            this.lbla.AutoSize = true;
            this.lbla.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbla.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbla.Location = new System.Drawing.Point(156, 61);
            this.lbla.Name = "lbla";
            this.lbla.Size = new System.Drawing.Size(65, 19);
            this.lbla.TabIndex = 10;
            this.lbla.Text = "Alerji :  ";
            // 
            // lbly
            // 
            this.lbly.AutoSize = true;
            this.lbly.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbly.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbly.Location = new System.Drawing.Point(35, 61);
            this.lbly.Name = "lbly";
            this.lbly.Size = new System.Drawing.Size(46, 19);
            this.lbly.TabIndex = 9;
            this.lbly.Text = "Yaş : ";
            // 
            // lblKro
            // 
            this.lblKro.AutoSize = true;
            this.lblKro.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKro.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblKro.Location = new System.Drawing.Point(470, 61);
            this.lblKro.Name = "lblKro";
            this.lblKro.Size = new System.Drawing.Size(0, 19);
            this.lblKro.TabIndex = 8;
            // 
            // lblAlerji
            // 
            this.lblAlerji.AutoSize = true;
            this.lblAlerji.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAlerji.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblAlerji.Location = new System.Drawing.Point(227, 61);
            this.lblAlerji.Name = "lblAlerji";
            this.lblAlerji.Size = new System.Drawing.Size(0, 19);
            this.lblAlerji.TabIndex = 7;
            // 
            // lblTc
            // 
            this.lblTc.AutoSize = true;
            this.lblTc.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTc.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblTc.Location = new System.Drawing.Point(322, 12);
            this.lblTc.Name = "lblTc";
            this.lblTc.Size = new System.Drawing.Size(0, 19);
            this.lblTc.TabIndex = 6;
            // 
            // lblYaş
            // 
            this.lblYaş.AutoSize = true;
            this.lblYaş.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblYaş.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblYaş.Location = new System.Drawing.Point(87, 61);
            this.lblYaş.Name = "lblYaş";
            this.lblYaş.Size = new System.Drawing.Size(0, 19);
            this.lblYaş.TabIndex = 5;
            // 
            // lblSoyad
            // 
            this.lblSoyad.AutoSize = true;
            this.lblSoyad.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSoyad.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblSoyad.Location = new System.Drawing.Point(156, 17);
            this.lblSoyad.Name = "lblSoyad";
            this.lblSoyad.Size = new System.Drawing.Size(0, 19);
            this.lblSoyad.TabIndex = 4;
            // 
            // lblAd
            // 
            this.lblAd.AutoSize = true;
            this.lblAd.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAd.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblAd.Location = new System.Drawing.Point(35, 17);
            this.lblAd.Name = "lblAd";
            this.lblAd.Size = new System.Drawing.Size(0, 19);
            this.lblAd.TabIndex = 3;
            // 
            // btnilaçekle
            // 
            this.btnilaçekle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(146)))), ((int)(((byte)(224)))));
            this.btnilaçekle.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnilaçekle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnilaçekle.Location = new System.Drawing.Point(548, 84);
            this.btnilaçekle.Name = "btnilaçekle";
            this.btnilaçekle.Size = new System.Drawing.Size(110, 24);
            this.btnilaçekle.TabIndex = 24;
            this.btnilaçekle.Text = "Ekle";
            this.btnilaçekle.UseVisualStyleBackColor = false;
            this.btnilaçekle.Click += new System.EventHandler(this.btnilaçekle_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Location = new System.Drawing.Point(33, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 12);
            this.label5.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(73, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 12);
            this.label2.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel5.Controls.Add(this.button1);
            this.panel5.Controls.Add(this.maxks);
            this.panel5.Controls.Add(this.gks);
            this.panel5.Controls.Add(this.ilacdozu);
            this.panel5.Controls.Add(this.txtKullŞekli);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.label8);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.label3);
            this.panel5.Controls.Add(this.txtİlaçAdı);
            this.panel5.Controls.Add(this.vScrollBar1);
            this.panel5.Controls.Add(this.btnKaydet);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.richTextBox1);
            this.panel5.Controls.Add(this.button4);
            this.panel5.Controls.Add(this.button5);
            this.panel5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(0, 114);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(669, 180);
            this.panel5.TabIndex = 0;
            // 
            // maxks
            // 
            this.maxks.FormattingEnabled = true;
            this.maxks.Items.AddRange(new object[] {
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.maxks.Location = new System.Drawing.Point(346, 100);
            this.maxks.Name = "maxks";
            this.maxks.Size = new System.Drawing.Size(102, 20);
            this.maxks.TabIndex = 35;
            // 
            // gks
            // 
            this.gks.FormattingEnabled = true;
            this.gks.Items.AddRange(new object[] {
            "2",
            "4",
            "6",
            "8",
            "10",
            "12",
            "24"});
            this.gks.Location = new System.Drawing.Point(346, 69);
            this.gks.Name = "gks";
            this.gks.Size = new System.Drawing.Size(102, 20);
            this.gks.TabIndex = 34;
            // 
            // ilacdozu
            // 
            this.ilacdozu.FormattingEnabled = true;
            this.ilacdozu.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5",
            "3",
            "3.5",
            "4",
            "4.5",
            "5"});
            this.ilacdozu.Location = new System.Drawing.Point(100, 70);
            this.ilacdozu.Name = "ilacdozu";
            this.ilacdozu.Size = new System.Drawing.Size(102, 20);
            this.ilacdozu.TabIndex = 1;
            // 
            // txtKullŞekli
            // 
            this.txtKullŞekli.Location = new System.Drawing.Point(99, 96);
            this.txtKullŞekli.Name = "txtKullŞekli";
            this.txtKullŞekli.Size = new System.Drawing.Size(103, 20);
            this.txtKullŞekli.TabIndex = 33;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label9.Location = new System.Drawing.Point(218, 100);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 12);
            this.label9.TabIndex = 31;
            this.label9.Text = "Max Kullanım Süresi";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label8.Location = new System.Drawing.Point(22, 100);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 12);
            this.label8.TabIndex = 30;
            this.label8.Text = "Kullanım Şekli";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label7.Location = new System.Drawing.Point(214, 69);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(114, 12);
            this.label7.TabIndex = 28;
            this.label7.Text = "Günlük Kullanım Süresi";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Location = new System.Drawing.Point(22, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 12);
            this.label6.TabIndex = 27;
            this.label6.Text = "İlaç Dozu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(22, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 12);
            this.label3.TabIndex = 25;
            this.label3.Text = "1. İlaç";
            // 
            // txtİlaçAdı
            // 
            this.txtİlaçAdı.Location = new System.Drawing.Point(99, 40);
            this.txtİlaçAdı.Name = "txtİlaçAdı";
            this.txtİlaçAdı.Size = new System.Drawing.Size(350, 20);
            this.txtİlaçAdı.TabIndex = 23;
            // 
            // vScrollBar1
            // 
            this.vScrollBar1.Location = new System.Drawing.Point(521, 28);
            this.vScrollBar1.Name = "vScrollBar1";
            this.vScrollBar1.Size = new System.Drawing.Size(21, 139);
            this.vScrollBar1.TabIndex = 22;
            // 
            // btnKaydet
            // 
            this.btnKaydet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(146)))), ((int)(((byte)(224)))));
            this.btnKaydet.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKaydet.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKaydet.Location = new System.Drawing.Point(548, 69);
            this.btnKaydet.Name = "btnKaydet";
            this.btnKaydet.Size = new System.Drawing.Size(110, 31);
            this.btnKaydet.TabIndex = 21;
            this.btnKaydet.Text = "KAYDET";
            this.btnKaydet.UseVisualStyleBackColor = false;
            this.btnKaydet.Click += new System.EventHandler(this.btnKaydet_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Location = new System.Drawing.Point(11, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 12);
            this.label4.TabIndex = 20;
            this.label4.Text = "Reçete yaz";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(11, 28);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(531, 139);
            this.richTextBox1.TabIndex = 19;
            this.richTextBox1.Text = "";
            // 
            // button4
            // 
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.Location = new System.Drawing.Point(606, 111);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(52, 56);
            this.button4.TabIndex = 18;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button5
            // 
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(548, 111);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(52, 56);
            this.button5.TabIndex = 17;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // serialPort1
            // 
            this.serialPort1.PortName = "COM8";
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived_1);
            // 
            // lbldocad
            // 
            this.lbldocad.AutoSize = true;
            this.lbldocad.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbldocad.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbldocad.Location = new System.Drawing.Point(221, 24);
            this.lbldocad.Name = "lbldocad";
            this.lbldocad.Size = new System.Drawing.Size(0, 19);
            this.lbldocad.TabIndex = 12;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(146)))), ((int)(((byte)(224)))));
            this.button1.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Location = new System.Drawing.Point(548, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 31);
            this.button1.TabIndex = 36;
            this.button1.Text = "Yeni Hasta";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Doctor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(855, 387);
            this.Controls.Add(this.lbldocad);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Doctor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "HealthFirst";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Doctor_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Doctor_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Doctor_MouseUp);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private ns1.BunifuFlatButton bunifuFlatButton1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label2;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblAd;
        private System.Windows.Forms.Label lblSoyad;
        private System.Windows.Forms.Label lblYaş;
        private System.Windows.Forms.Label lblTc;
        private System.Windows.Forms.Label lblKro;
        private System.Windows.Forms.Button btnKaydet;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label lbly;
        private System.Windows.Forms.Label lbla;
        private System.Windows.Forms.Label lblk;
        private System.Windows.Forms.Label lbldocad;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.VScrollBar vScrollBar1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtİlaçAdı;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtKullŞekli;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox ilacdozu;
        private System.Windows.Forms.ComboBox maxks;
        private System.Windows.Forms.ComboBox gks;
        private System.Windows.Forms.Label lblAlerji;
        private System.Windows.Forms.Button btnilaçekle;
        private System.Windows.Forms.Label ilac;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblverildigitarih;
        private System.Windows.Forms.Button button1;
    }
}

