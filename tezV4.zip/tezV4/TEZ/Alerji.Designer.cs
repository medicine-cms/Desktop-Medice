﻿namespace TEZ
{
    partial class Alerji
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAd = new System.Windows.Forms.Label();
            this.lbltc = new System.Windows.Forms.Label();
            this.lblAlerji = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblKro = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lblSoyad = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblAd
            // 
            this.lblAd.AutoSize = true;
            this.lblAd.Location = new System.Drawing.Point(13, 13);
            this.lblAd.Name = "lblAd";
            this.lblAd.Size = new System.Drawing.Size(0, 13);
            this.lblAd.TabIndex = 0;
            // 
            // lbltc
            // 
            this.lbltc.AutoSize = true;
            this.lbltc.Location = new System.Drawing.Point(13, 45);
            this.lbltc.Name = "lbltc";
            this.lbltc.Size = new System.Drawing.Size(0, 13);
            this.lbltc.TabIndex = 1;
            this.lbltc.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblAlerji
            // 
            this.lblAlerji.AutoSize = true;
            this.lblAlerji.Location = new System.Drawing.Point(13, 85);
            this.lblAlerji.Name = "lblAlerji";
            this.lblAlerji.Size = new System.Drawing.Size(0, 13);
            this.lblAlerji.TabIndex = 2;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(85, 85);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 3;
            // 
            // lblKro
            // 
            this.lblKro.AutoSize = true;
            this.lblKro.Location = new System.Drawing.Point(13, 127);
            this.lblKro.Name = "lblKro";
            this.lblKro.Size = new System.Drawing.Size(0, 13);
            this.lblKro.TabIndex = 4;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(85, 124);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(85, 193);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblSoyad
            // 
            this.lblSoyad.AutoSize = true;
            this.lblSoyad.Location = new System.Drawing.Point(82, 13);
            this.lblSoyad.Name = "lblSoyad";
            this.lblSoyad.Size = new System.Drawing.Size(0, 13);
            this.lblSoyad.TabIndex = 7;
            // 
            // Alerji
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.lblSoyad);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.lblKro);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblAlerji);
            this.Controls.Add(this.lbltc);
            this.Controls.Add(this.lblAd);
            this.Name = "Alerji";
            this.Text = "Alerji";
            this.Load += new System.EventHandler(this.Alerji_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAd;
        private System.Windows.Forms.Label lbltc;
        private System.Windows.Forms.Label lblAlerji;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblKro;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblSoyad;
    }
}