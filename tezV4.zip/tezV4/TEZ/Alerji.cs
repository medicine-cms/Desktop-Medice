﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TEZ.Data;

namespace TEZ
{
    public partial class Alerji : Form
    {
        public Alerji()
        {
            InitializeComponent();

        }
        
        public string hastaidalerji { get; set; }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void Alerji_Load(object sender, EventArgs e)
        {
            SqlConnection cnn = DBConnect.getConnection();
            cnn.Open();
            int hastaidint = Int32.Parse(hastaidalerji);            
            string sqlSelectQuery = "SELECT * FROM HASTA WHERE HASTA_ID= '" + hastaidint + "'";
            SqlCommand cmd = new SqlCommand(sqlSelectQuery, cnn);
            SqlDataReader dr = cmd.ExecuteReader();           
            if (dr.Read())
            {
                
                lbltc.Text = (dr["Hasta_TC_Kimlik_No"].ToString());
                lblAd.Text = (dr["Hasta_Ad"].ToString());
                lblSoyad.Text = (dr["Hasta_Soyad"].ToString());
               
            }
            else
            {
                MessageBox.Show("problem oluştu!!!!!!!");
            }
            dr.Close();
            cnn.Close();          

        }

        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection cnn = DBConnect.getConnection();
            cnn.Open();
           
            int hastaidint = Int32.Parse(hastaidalerji);
            string Alerjigüncelleme = "UPDATE HASTA SET Alerji=@Alerji,Kronik_Hastalik=@Kronik_Hastalik WHERE HASTA_ID='" + hastaidint + "'";
            SqlCommand cmd = new SqlCommand(Alerjigüncelleme, cnn);
            cmd.Parameters.AddWithValue("@Alerji", textBox1.Text);
            cmd.Parameters.AddWithValue("@Kronik_Hastalik", textBox2.Text);
            cmd.ExecuteNonQuery();
            cnn.Close();
            
            MessageBox.Show("Güncellendi.");
        }

       
    }
}
